def makes10(a, b):
  return (a == 10 or b == 10 or a+b == 10)