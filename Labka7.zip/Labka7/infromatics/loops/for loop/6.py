a = input()
reva = ''
for i in a:
    reva=i+reva

print(reva)