n = int(input())
divider = 2

while n % divider != 0:
    divider += 1

print(divider)
