a = int(input())
b = int(input())

print("YES" if a==b else "NO") 